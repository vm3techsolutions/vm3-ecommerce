const express = require("express");
const router = express.Router();
const { registerUser, loginUser, forgotPassword, resetPassword } = require("../Controller/userController");

// Registration route
router.post("/register", registerUser);

// ✅ Login route
router.post("/login", loginUser);

// ✅ Forgot-Password route
router.post("/forgot-password", forgotPassword);

// ✅ Reset-Password route
router.post("/reset-password/:token", resetPassword);

module.exports = router;

