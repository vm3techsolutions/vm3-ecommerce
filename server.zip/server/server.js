// server.js
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { connectDB } = require("./Config/db");

const roleRoutes = require("./Router/role-router");
const authRoutes = require("./Router/auth-router");
const categoryRoutes = require("./Router/category");
const planRoutes = require("./Router/plans");

dotenv.config();
const app = express(); // ✅ Declare `app` before using it
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

connectDB();

// ✅ Mount routes after `app` is initialized
app.use("/api/roles", roleRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/categories", categoryRoutes); 
app.use("/api/plans", planRoutes);

app.listen(PORT, () =>
  console.log(`Server running on port ${PORT}`)
);
